<div class="b2s-dashboard-multi-widget" data-position="0">
    <h5 class="b2s-dashboard-h5"></h5>
    <div class="b2s-dashboard-multi-widget-inner">
        <i class="glyphicon glyphicon-chevron-left"></i>
        <div class="b2s-dashboard-multi-widget-content col-md-12">
            <div class="b2s-loader-impulse b2s-loader-impulse-md"></div>
        </div>
        <i class="glyphicon glyphicon-chevron-right"></i>
    </div>
</div>